package com.example.apppokedex.database

interface InputDialogListener {
    fun onInputDone(input: Int)

    fun onInputStringDone(input: String)

}