package com.example.apppokedex.fragments

import androidx.lifecycle.ViewModel

class FragmentPcViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}