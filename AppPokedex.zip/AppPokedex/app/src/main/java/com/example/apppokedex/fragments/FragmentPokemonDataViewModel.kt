package com.example.apppokedex.fragments

import androidx.lifecycle.ViewModel

class FragmentPokemonDataViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}