package com.example.apppokedex.fragments

import androidx.lifecycle.ViewModel

class FragmentRegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}